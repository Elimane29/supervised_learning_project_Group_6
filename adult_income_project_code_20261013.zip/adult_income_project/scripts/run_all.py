#!/usr/bin/env python3
from adult_income.run_all import main
if __name__ == '__main__': main()
