# Adult Census Income - Trustworthy Supervised Learning Project

**Dataset:** Adult / Census Income (OpenML `adult`, version 2)  
**Task:** predict whether annual income is `>50K` from tabular census attributes.  
**Sensitive attribute for the fairness audit:** `sex`.

This repository implements the official MSA-DATB09-04 project requirements end to end: EDA, honest train/validation/test splitting, missing-value handling, five justified engineered features, class-imbalance handling, three-model progression, one preprocessing/model Pipeline, Optuna tuning inside cross-validation, file-based experiment tracking, SHAP and permutation explanations, calibration, fairness mitigation, and a FastAPI prediction endpoint.

## 1. Reproduce the project

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install -e .
python scripts/run_all.py --data-mode openml
```

For a faster rehearsal:

```bash
python scripts/run_all.py --data-mode openml --trials 5
```

Offline smoke test only:

```bash
pytest -q
python scripts/run_all.py --data-mode fixture --skip-tuning
```

The fixture is deliberately not used for final claims.

## 2. Methodology

1. Hold out 20% as the untouched test set.
2. Split the remaining development data into training and validation sets.
3. Engineer prediction-time features: net capital, capital activity, education-hours interaction, age-hours ratio, and marital indicator.
4. Fit imputation, encoding/scaling, and the estimator inside one `Pipeline`.
5. Compare regularized Logistic Regression, Random Forest, and LightGBM with the same metrics.
6. Tune each model with Optuna and stratified cross-validation using PR-AUC.
7. Use class weights to address imbalance; choose the decision threshold on validation data.
8. Calibrate the selected model with sigmoid calibration using validation data.
9. Open the test set once for final performance, calibration, explanation, and fairness evidence.
10. Audit fairness by sex. The declared primary definition is equal opportunity. Fit group thresholds on validation data, then compare before/after gaps on the untouched test set.

## 3. Outputs

- `artifacts/results.json` - final model, test metrics, calibration and fairness summary.
- `artifacts/model_comparison.csv` - same validation metrics for all three models.
- `artifacts/optuna_*.csv` - every tuning trial.
- `artifacts/tracking/runs.jsonl` - parameters and metrics for every logged model run.
- `artifacts/*.png` - EDA, comparison, PR/ROC, confusion matrix, calibration, explainability and fairness plots.
- `models/final_model.joblib` - calibrated fitted workflow and threshold.

## 4. Serve the endpoint

```bash
python scripts/serve.py
curl http://localhost:8000/health
```

POST a JSON census record to `/predict`. The endpoint returns the calibrated probability, class decision, threshold and model name.

## 5. Important interpretation

- `>50K` is a historical income label, not a measure of merit or need.
- Accuracy is secondary because the positive class is less common; PR-AUC is the primary ranking metric.
- Calibration and ranking are separate questions.
- Removing `sex` from model inputs does not guarantee fairness because proxy variables remain.
- Group-specific thresholds are an analytical mitigation, not an automatic deployment recommendation. Legal, ethical and operational review is required.

## 6. Academic integrity and AI disclosure

AI assistance was used to help scaffold code structure, documentation, tests and presentation wording. The group must review, run, understand and defend every step, verify the generated artifacts, and disclose any retained AI-assisted work in the final report.

## 7. Contribution statement

The final report must replace the template below with the real group members and work performed.

| Member | Main contribution | Cross-check responsibility |
|---|---|---|
| Name 1 | Data/EDA and feature engineering | Explain modelling and leakage controls |
| Name 2 | Modelling, tuning and tracking | Explain calibration and thresholding |
| Name 3 | Explainability, fairness and deployment | Explain preprocessing and evaluation |

## 8. Git history

This package starts a clean repository, but the official brief requires genuine incremental work. Continue committing meaningful changes throughout the project. Do not replace real teamwork with a single final commit.
