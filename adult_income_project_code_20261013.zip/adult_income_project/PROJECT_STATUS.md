# Project status and evidence boundary

## Completed in this package

- Full Python implementation for all ten technical requirements in the official Project Instructions.
- Clean script-based repository with configuration, requirements, tests, FastAPI endpoint and LaTeX report template.
- Unit/integration tests pass in the supplied environment.
- End-to-end smoke execution was validated with the small real-data fixture.

## Required before final submission

The execution environment used to build this package could not download the complete OpenML Adult v2 file. Therefore, **no smoke-fixture metric is valid final evidence** and the presentation intentionally contains no unverified model score.

Run this command in an internet-enabled environment:

```bash
pip install -r requirements.txt
pip install -e .
python scripts/run_all.py --data-mode openml
```

Then verify:

1. `artifacts/dataset_metadata.json` identifies `OpenML adult v2` and the complete row count.
2. `artifacts/model_comparison.csv` contains all three models.
3. `artifacts/optuna_*.csv` contains the tuning trials.
4. `artifacts/results.json` contains untouched-test metrics and fairness before/after results.
5. All EDA, evaluation, calibration, SHAP and fairness plots have been reviewed.
6. The presentation is updated only with these full-run figures.
7. The LaTeX report is completed with the real repository URL, group names, contribution statement, plots, results and interpretations.

## Integrity note

The included Git commits are a structured starter history created with the implementation. They do not replace the official requirement for genuine incremental group work over the project timeline. Continue committing real changes with meaningful messages.
