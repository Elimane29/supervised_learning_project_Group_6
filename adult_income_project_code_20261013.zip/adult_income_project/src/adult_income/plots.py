from __future__ import annotations
from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.calibration import calibration_curve
from sklearn.metrics import PrecisionRecallDisplay, RocCurveDisplay, ConfusionMatrixDisplay

COLORS={"navy":"#16233A","coral":"#FF3D68","teal":"#00A6A6","gold":"#F2B134","gray":"#5A6470"}
def _save(fig,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);fig.tight_layout();fig.savefig(path,dpi=180,bbox_inches="tight");plt.close(fig);return path

def plot_eda(X,y,out):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(figsize=(6.4,3.6)); y.value_counts(normalize=True).sort_index().plot.bar(ax=ax,color=[COLORS['navy'],COLORS['coral']]);ax.set_xticklabels(["<=50K",">50K"],rotation=0);ax.set_ylabel("Share");ax.set_title("Target distribution");_save(fig,out/'eda_target.png')
    fig,ax=plt.subplots(figsize=(7,4)); temp=pd.DataFrame({'age':X['age'],'income':y}).dropna();temp.boxplot(column='age',by='income',ax=ax,grid=False);ax.set_title('Age by target');fig.suptitle('');ax.set_xlabel('Income class');_save(fig,out/'eda_age.png')

def plot_curves(y,probability,out,prefix):
    out=Path(out);out.mkdir(parents=True,exist_ok=True)
    fig,ax=plt.subplots(figsize=(5.6,4));PrecisionRecallDisplay.from_predictions(y,probability,ax=ax,color=COLORS['coral']);ax.axhline(np.mean(y),ls='--',color=COLORS['gray'],label='Prevalence');ax.legend();ax.set_title('Precision-recall curve');_save(fig,out/f'{prefix}_pr_curve.png')
    fig,ax=plt.subplots(figsize=(5.6,4));RocCurveDisplay.from_predictions(y,probability,ax=ax,color=COLORS['teal']);ax.plot([0,1],[0,1],'--',color=COLORS['gray']);ax.set_title('ROC curve');_save(fig,out/f'{prefix}_roc_curve.png')

def plot_confusion(y,pred,out,prefix):
    fig,ax=plt.subplots(figsize=(4.8,4));ConfusionMatrixDisplay.from_predictions(y,pred,ax=ax,cmap='Blues',colorbar=False);ax.set_title('Confusion matrix');return _save(fig,Path(out)/f'{prefix}_confusion.png')

def plot_calibration(y,probability,out,prefix):
    frac,mean=calibration_curve(y,probability,n_bins=10,strategy='quantile')
    fig,(ax,hist)=plt.subplots(2,1,figsize=(5.8,5.6),gridspec_kw={'height_ratios':[3,1]});ax.plot([0,1],[0,1],'--',color=COLORS['gray']);ax.plot(mean,frac,'o-',color=COLORS['gold']);ax.set(xlabel='Mean predicted probability',ylabel='Observed positive rate',title='Reliability diagram');hist.hist(probability,bins=15,color=COLORS['navy']);hist.set(xlabel='Predicted probability',ylabel='Count');return _save(fig,Path(out)/f'{prefix}_calibration.png')

def plot_model_comparison(table,out):
    frame=table.set_index('model')[['pr_auc','roc_auc','f1','recall']]
    fig,ax=plt.subplots(figsize=(8,4.5));frame.plot.bar(ax=ax,color=[COLORS['coral'],COLORS['teal'],COLORS['gold'],COLORS['navy']]);ax.set_ylim(0,1);ax.set_ylabel('Score');ax.set_xticklabels(ax.get_xticklabels(),rotation=0);ax.set_title('Validation comparison using the same metrics');ax.legend(ncol=4,loc='lower center',bbox_to_anchor=(.5,1.01));return _save(fig,Path(out)/'model_comparison.png')

def plot_fairness(before,after,out):
    merged=before[['group','tpr','fpr','selection_rate']].merge(after[['group','tpr','fpr','selection_rate']],on='group',suffixes=('_before','_after'))
    long=merged.melt(id_vars='group',var_name='metric',value_name='value')
    fig,ax=plt.subplots(figsize=(8,4.5));
    for i,(metric,g) in enumerate(long.groupby('metric')): ax.bar(np.arange(len(g))+.12*i,g.value,width=.11,label=metric)
    ax.set_xticks(np.arange(len(merged))+.28);ax.set_xticklabels(merged.group);ax.set_ylim(0,1);ax.set_ylabel('Rate');ax.set_title('Fairness audit: before vs after mitigation');ax.legend(fontsize=7,ncol=3);return _save(fig,Path(out)/'fairness_before_after.png')
