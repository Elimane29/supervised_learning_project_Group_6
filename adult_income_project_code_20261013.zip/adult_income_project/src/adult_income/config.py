from __future__ import annotations
from pathlib import Path
import yaml


def load_config(path: str | Path = "config.yaml") -> dict:
    path = Path(path)
    with path.open("r", encoding="utf-8") as handle:
        cfg = yaml.safe_load(handle)
    cfg["_root"] = str(path.resolve().parent)
    return cfg


def resolve(cfg: dict, relative: str) -> Path:
    return Path(cfg["_root"]) / relative
