from __future__ import annotations
from pathlib import Path
import joblib
import pandas as pd
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, ConfigDict

class PredictionRequest(BaseModel):
    model_config=ConfigDict(extra='allow')
    age: float
    workclass: str | None=None
    fnlwgt: float | None=None
    education: str | None=None
    education_num: float | None=None
    marital_status: str | None=None
    occupation: str | None=None
    relationship: str | None=None
    race: str | None=None
    sex: str | None=None
    capital_gain: float=0
    capital_loss: float=0
    hours_per_week: float
    native_country: str | None=None


def create_app(model_path='models/final_model.joblib'):
    app=FastAPI(title='Adult Income Prediction API',version='1.0.0')
    bundle_path=Path(model_path)
    @app.get('/health')
    def health(): return {'status':'ok','model_loaded':bundle_path.exists()}
    @app.post('/predict')
    def predict(request:PredictionRequest):
        if not bundle_path.exists(): raise HTTPException(503,'Model artifact not found. Run the training pipeline first.')
        bundle=joblib.load(bundle_path)
        row=request.model_dump()
        rename={'education_num':'education-num','marital_status':'marital-status','capital_gain':'capital-gain','capital_loss':'capital-loss','hours_per_week':'hours-per-week','native_country':'native-country'}
        row={rename.get(k,k):v for k,v in row.items()}
        frame=pd.DataFrame([row]); probability=float(bundle['model'].predict_proba(frame)[:,1][0]); threshold=float(bundle['threshold']); prediction=int(probability>=threshold)
        return {'probability_over_50k':probability,'prediction':'>50K' if prediction else '<=50K','threshold':threshold,'model_name':bundle['model_name']}
    return app

app=create_app()
