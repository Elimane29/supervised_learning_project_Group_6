from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split

MISSING_TOKENS = ["?", " ?", "", "NA", "N/A"]
COLUMN_ALIASES = {
    "education.num": "education-num",
    "marital.status": "marital-status",
    "capital.gain": "capital-gain",
    "capital.loss": "capital-loss",
    "hours.per.week": "hours-per-week",
    "native.country": "native-country",
}

@dataclass
class DataSplits:
    X_train: pd.DataFrame
    X_validation: pd.DataFrame
    X_test: pd.DataFrame
    y_train: pd.Series
    y_validation: pd.Series
    y_test: pd.Series
    sensitive_train: pd.Series
    sensitive_validation: pd.Series
    sensitive_test: pd.Series


def _normalise_frame(frame: pd.DataFrame, target: pd.Series | None = None) -> tuple[pd.DataFrame, pd.Series]:
    frame = frame.rename(columns=COLUMN_ALIASES).copy()
    frame.columns = [str(c).strip().lower().replace("_", "-") for c in frame.columns]
    frame = frame.replace(MISSING_TOKENS, np.nan)
    for col in frame.select_dtypes(include=["object", "category"]).columns:
        cleaned = frame[col].astype("string").str.strip().replace({"?": pd.NA})
        frame[col] = cleaned.astype(object).where(cleaned.notna(), np.nan)
    if target is None:
        for candidate in ["income", "class", "target"]:
            if candidate in frame.columns:
                target = frame.pop(candidate)
                break
    if target is None:
        raise ValueError("Target column was not found.")
    y = pd.Series(target, index=frame.index, name="income").astype("string").str.strip().str.replace(".", "", regex=False)
    y = (y == ">50K").astype(int)
    return frame, y


def load_adult(cfg: dict, mode: str = "auto") -> tuple[pd.DataFrame, pd.Series, str]:
    root = Path(cfg["_root"])
    data_cfg = cfg["data"]
    errors: list[str] = []
    if mode in {"auto", "openml"}:
        try:
            bunch = fetch_openml(
                name=data_cfg["openml_name"], version=data_cfg["openml_version"],
                as_frame=True, parser="auto"
            )
            X, y = _normalise_frame(bunch.data, bunch.target)
            return X, y, "OpenML adult v2"
        except Exception as exc:  # network/cache errors get an explicit fallback
            errors.append(f"OpenML: {type(exc).__name__}: {exc}")
            if mode == "openml":
                raise RuntimeError("OpenML loading failed: " + errors[-1]) from exc
    fallback = root / data_cfg["local_fallback"]
    if mode in {"auto", "local"} and fallback.exists():
        raw = pd.read_csv(fallback, na_values=MISSING_TOKENS, skipinitialspace=True)
        X, y = _normalise_frame(raw)
        return X, y, f"local cached Adult data: {fallback.name}"
    fixture = root / data_cfg["fixture"]
    if mode in {"fixture", "auto"} and fixture.exists():
        raw = pd.read_csv(fixture, na_values=MISSING_TOKENS, skipinitialspace=True).drop_duplicates()
        X, y = _normalise_frame(raw)
        return X, y, f"small real-data fixture for smoke testing: {fixture.name}"
    raise FileNotFoundError("No Adult data source available. " + " | ".join(errors))


def split_data(X: pd.DataFrame, y: pd.Series, cfg: dict) -> DataSplits:
    seed = cfg["project"]["random_state"]
    sensitive_name = cfg["data"]["sensitive_attribute"]
    if sensitive_name not in X.columns:
        raise KeyError(f"Sensitive attribute '{sensitive_name}' is missing")
    X_dev, X_test, y_dev, y_test = train_test_split(
        X, y, test_size=cfg["data"]["test_size"], stratify=y, random_state=seed
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_dev, y_dev,
        test_size=cfg["data"]["validation_size_within_development"],
        stratify=y_dev, random_state=seed
    )
    return DataSplits(
        X_train=X_train.reset_index(drop=True),
        X_validation=X_val.reset_index(drop=True),
        X_test=X_test.reset_index(drop=True),
        y_train=y_train.reset_index(drop=True),
        y_validation=y_val.reset_index(drop=True),
        y_test=y_test.reset_index(drop=True),
        sensitive_train=X_train[sensitive_name].astype("string").reset_index(drop=True),
        sensitive_validation=X_val[sensitive_name].astype("string").reset_index(drop=True),
        sensitive_test=X_test[sensitive_name].astype("string").reset_index(drop=True),
    )
