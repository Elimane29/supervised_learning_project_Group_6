from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.metrics import confusion_matrix, precision_score

def _rates(y, pred):
    tn, fp, fn, tp = confusion_matrix(y, pred, labels=[0,1]).ravel()
    return {"selection_rate": float(pred.mean()), "tpr": float(tp/(tp+fn)) if tp+fn else np.nan, "fpr": float(fp/(fp+tn)) if fp+tn else np.nan, "ppv": float(precision_score(y,pred,zero_division=0)), "n": int(len(y)), "positives": int(np.sum(y))}

def group_metrics(y_true, probability, sensitive, threshold=0.5) -> tuple[pd.DataFrame, dict]:
    y = np.asarray(y_true); p = np.asarray(probability); a = pd.Series(sensitive).fillna("Missing").astype(str).to_numpy()
    rows=[]
    for group in sorted(np.unique(a)):
        mask=a==group; rows.append({"group":group, **_rates(y[mask], (p[mask]>=threshold).astype(int))})
    table=pd.DataFrame(rows)
    if len(table)>=2:
        summary={
            "demographic_parity_difference": float(table.selection_rate.max()-table.selection_rate.min()),
            "demographic_parity_ratio": float(table.selection_rate.min()/table.selection_rate.max()) if table.selection_rate.max() else np.nan,
            "equal_opportunity_difference": float(table.tpr.max()-table.tpr.min()),
            "fpr_difference": float(table.fpr.max()-table.fpr.min()),
            "equalized_odds_difference": float(max(table.tpr.max()-table.tpr.min(), table.fpr.max()-table.fpr.min())),
            "predictive_parity_difference": float(table.ppv.max()-table.ppv.min()),
        }
    else: summary={}
    return table,summary

def fit_equal_opportunity_thresholds(y_true, probability, sensitive, target_tpr=None):
    y=np.asarray(y_true); p=np.asarray(probability); a=pd.Series(sensitive).fillna("Missing").astype(str).to_numpy()
    groups=sorted(np.unique(a)); grid=np.linspace(.05,.95,181)
    if target_tpr is None:
        base=[]
        for g in groups:
            m=a==g; base.append(_rates(y[m],(p[m]>=.5).astype(int))["tpr"])
        target_tpr=float(np.nanmean(base))
    thresholds={}
    for g in groups:
        m=a==g; best=None
        for t in grid:
            r=_rates(y[m],(p[m]>=t).astype(int))
            key=(abs(r["tpr"]-target_tpr), r["fpr"], abs(t-.5))
            if best is None or key<best[0]: best=(key,float(t))
        thresholds[g]=best[1]
    return thresholds

def apply_group_thresholds(probability, sensitive, thresholds, default=0.5):
    p=np.asarray(probability); a=pd.Series(sensitive).fillna("Missing").astype(str).to_numpy()
    return np.asarray([int(prob>=thresholds.get(group,default)) for prob,group in zip(p,a)])
