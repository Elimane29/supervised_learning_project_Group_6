from __future__ import annotations
import json
from pathlib import Path
import numpy as np
from sklearn.model_selection import StratifiedKFold, cross_val_score
from .modeling import make_pipeline

SEARCH_SPACES = {
    "logistic_regression": {"C": (1e-3, 30.0), "penalty": ["l1", "l2"]},
    "random_forest": {"max_depth": (4, 20), "min_samples_leaf": (1, 20), "max_features": ["sqrt", "log2", 0.5]},
    "lightgbm": {"num_leaves": (15, 63), "learning_rate": (0.01, 0.2), "max_depth": (3, 12), "min_child_samples": (10, 80)},
}

def _suggest(trial, name):
    if name == "logistic_regression": return {"C": trial.suggest_float("C", 1e-3, 30, log=True), "penalty": trial.suggest_categorical("penalty", ["l1", "l2"])}
    if name == "random_forest": return {"max_depth": trial.suggest_int("max_depth", 4, 20), "min_samples_leaf": trial.suggest_int("min_samples_leaf", 1, 20), "max_features": trial.suggest_categorical("max_features", ["sqrt", "log2", 0.5])}
    return {"num_leaves": trial.suggest_int("num_leaves", 15, 63), "learning_rate": trial.suggest_float("learning_rate", 0.01, 0.2, log=True), "max_depth": trial.suggest_int("max_depth", 3, 12), "min_child_samples": trial.suggest_int("min_child_samples", 10, 80)}

def tune_model(name, X, y, cfg, output_dir: str | Path, trials: int | None = None):
    try:
        import optuna
    except ImportError as exc:
        raise RuntimeError("Optuna is required for the final project. Install requirements.txt.") from exc
    seed = cfg["project"]["random_state"]
    n_trials = int(trials or cfg["modeling"]["optuna_trials"])
    cv = StratifiedKFold(n_splits=cfg["modeling"]["cv_folds"], shuffle=True, random_state=seed)
    def objective(trial):
        params = _suggest(trial, name)
        pipeline = make_pipeline(name, cfg, params)
        scores = cross_val_score(pipeline, X, y, cv=cv, scoring="average_precision", n_jobs=1)
        trial.set_user_attr("fold_scores", scores.tolist())
        return float(scores.mean())
    sampler = optuna.samplers.TPESampler(seed=seed)
    study = optuna.create_study(direction="maximize", sampler=sampler, study_name=name)
    study.optimize(objective, n_trials=n_trials, show_progress_bar=False)
    output_dir = Path(output_dir); output_dir.mkdir(parents=True, exist_ok=True)
    study.trials_dataframe().to_csv(output_dir / f"optuna_{name}.csv", index=False)
    (output_dir / f"optuna_{name}_best.json").write_text(json.dumps({"value": study.best_value, "params": study.best_params}, indent=2), encoding="utf-8")
    return study.best_params, float(study.best_value)
