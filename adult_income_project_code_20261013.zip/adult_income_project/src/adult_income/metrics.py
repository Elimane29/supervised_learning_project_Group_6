from __future__ import annotations
import numpy as np
from sklearn.metrics import (
    average_precision_score, roc_auc_score, precision_score, recall_score,
    f1_score, accuracy_score, confusion_matrix, brier_score_loss, log_loss
)


def expected_calibration_error(y_true, probability, bins: int = 10) -> float:
    y = np.asarray(y_true)
    p = np.asarray(probability)
    edges = np.linspace(0, 1, bins + 1)
    ids = np.clip(np.digitize(p, edges, right=True) - 1, 0, bins - 1)
    ece = 0.0
    for idx in range(bins):
        mask = ids == idx
        if mask.any():
            ece += mask.mean() * abs(y[mask].mean() - p[mask].mean())
    return float(ece)


def classification_metrics(y_true, probability, threshold: float = 0.5) -> dict[str, float]:
    pred = (np.asarray(probability) >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred, labels=[0, 1]).ravel()
    return {
        "pr_auc": float(average_precision_score(y_true, probability)),
        "roc_auc": float(roc_auc_score(y_true, probability)),
        "precision": float(precision_score(y_true, pred, zero_division=0)),
        "recall": float(recall_score(y_true, pred, zero_division=0)),
        "f1": float(f1_score(y_true, pred, zero_division=0)),
        "accuracy": float(accuracy_score(y_true, pred)),
        "brier": float(brier_score_loss(y_true, probability)),
        "ece_10": expected_calibration_error(y_true, probability, 10),
        "log_loss": float(log_loss(y_true, np.clip(probability, 1e-7, 1-1e-7))),
        "tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp),
        "threshold": float(threshold),
    }


def select_threshold(y_true, probability, objective: str = "f1") -> tuple[float, dict]:
    candidates = np.linspace(0.05, 0.95, 181)
    best = None
    for threshold in candidates:
        metrics = classification_metrics(y_true, probability, threshold)
        score = metrics[objective]
        if best is None or score > best[0]:
            best = (score, float(threshold), metrics)
    return best[1], best[2]
