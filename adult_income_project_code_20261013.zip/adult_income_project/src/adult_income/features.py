from __future__ import annotations
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

class AdultFeatureEngineer(BaseEstimator, TransformerMixin):
    """Create justified, prediction-time features without learning from the target."""
    def fit(self, X: pd.DataFrame, y=None):
        self.feature_names_in_ = np.asarray(X.columns, dtype=object)
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        out = X.copy()
        gain = pd.to_numeric(out.get("capital-gain", 0), errors="coerce").fillna(0)
        loss = pd.to_numeric(out.get("capital-loss", 0), errors="coerce").fillna(0)
        hours = pd.to_numeric(out.get("hours-per-week", np.nan), errors="coerce")
        education = pd.to_numeric(out.get("education-num", np.nan), errors="coerce")
        age = pd.to_numeric(out.get("age", np.nan), errors="coerce")
        out["capital-net"] = gain - loss
        out["has-capital-activity"] = ((gain > 0) | (loss > 0)).astype(int)
        out["education-hours"] = education * hours
        out["age-hours-ratio"] = age / hours.clip(lower=1)
        marital = out.get("marital-status", pd.Series(pd.NA, index=out.index)).astype("string")
        out["is-married"] = marital.str.startswith("Married", na=False).astype(int)
        return out
