from __future__ import annotations
from pathlib import Path
import json
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.inspection import permutation_importance

def explain_model(pipeline, X, y, out_dir, max_rows=500, local_rows=3):
    out=Path(out_dir);out.mkdir(parents=True,exist_ok=True)
    sample=X.iloc[:min(max_rows,len(X))].copy(); target=y.iloc[:len(sample)]
    perm=permutation_importance(pipeline,sample,target,scoring='average_precision',n_repeats=5,random_state=42,n_jobs=1)
    perm_df=pd.DataFrame({'feature':X.columns,'importance_mean':perm.importances_mean,'importance_std':perm.importances_std}).sort_values('importance_mean',ascending=False)
    perm_df.to_csv(out/'permutation_importance.csv',index=False)
    top=perm_df.head(12).sort_values('importance_mean')
    fig,ax=plt.subplots(figsize=(7,4.8));ax.barh(top.feature,top.importance_mean,xerr=top.importance_std,color='#00A6A6');ax.set_xlabel('Decrease in PR-AUC after permutation');ax.set_title('Global permutation importance');fig.tight_layout();fig.savefig(out/'permutation_importance.png',dpi=180,bbox_inches='tight');plt.close(fig)
    shap_status={'created':False,'reason':None}
    try:
        import shap
        features=pipeline[:-1].transform(sample)
        model=pipeline.named_steps['model']
        names=pipeline.named_steps['preprocess'].get_feature_names_out()
        dense=features.toarray() if hasattr(features,'toarray') and features.shape[1]<300 else features
        background=dense[:min(100,len(sample))]
        explain_rows=dense[:min(max_rows,len(sample))]
        if model.__class__.__name__.lower().startswith(('lgbm','randomforest')):
            explainer=shap.TreeExplainer(model)
            values=explainer(explain_rows)
            if getattr(values.values,'ndim',2)==3: values=values[:,:,1]
        else:
            explainer=shap.LinearExplainer(model,background)
            values=explainer(explain_rows)
        plt.figure();shap.plots.bar(values,max_display=12,show=False);plt.tight_layout();plt.savefig(out/'shap_global.png',dpi=180,bbox_inches='tight');plt.close()
        for i in range(min(local_rows,len(sample))):
            plt.figure();shap.plots.waterfall(values[i],max_display=12,show=False);plt.tight_layout();plt.savefig(out/f'shap_local_{i+1}.png',dpi=180,bbox_inches='tight');plt.close()
        shap_status={'created':True,'rows':int(len(sample)),'local_explanations':min(local_rows,len(sample))}
    except Exception as exc:
        shap_status={'created':False,'reason':f'{type(exc).__name__}: {exc}'}
    (out/'shap_status.json').write_text(json.dumps(shap_status,indent=2),encoding='utf-8')
    return perm_df,shap_status
