from __future__ import annotations
import numpy as np
from sklearn.compose import ColumnTransformer, make_column_selector
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, HistGradientBoostingClassifier
from .features import AdultFeatureEngineer

def drop_sensitive_column(frame, column="sex"):
    return frame.drop(columns=[column], errors="ignore")


def make_preprocessor() -> ColumnTransformer:
    numeric = Pipeline([
        ("impute", SimpleImputer(strategy="median", add_indicator=True)),
        ("scale", StandardScaler()),
    ])
    categorical = Pipeline([
        ("impute", SimpleImputer(strategy="most_frequent")),
        ("encode", OneHotEncoder(handle_unknown="ignore", min_frequency=5, sparse_output=True)),
    ])
    return ColumnTransformer([
        ("numeric", numeric, make_column_selector(dtype_include=np.number)),
        ("categorical", categorical, make_column_selector(dtype_exclude=np.number)),
    ], verbose_feature_names_out=False)


def make_estimator(name: str, seed: int, params: dict | None = None):
    params = params or {}
    if name == "logistic_regression":
        return LogisticRegression(max_iter=2000, class_weight="balanced", solver="liblinear", random_state=seed, **params)
    if name == "random_forest":
        return RandomForestClassifier(n_estimators=350, class_weight="balanced", n_jobs=-1, random_state=seed, **params)
    if name == "lightgbm":
        try:
            from lightgbm import LGBMClassifier
            return LGBMClassifier(n_estimators=400, class_weight="balanced", random_state=seed, verbosity=-1, n_jobs=-1, **params)
        except ImportError:
            return HistGradientBoostingClassifier(random_state=seed, **params)
    raise ValueError(f"Unknown model: {name}")


def make_pipeline(name: str, cfg: dict, params: dict | None = None) -> Pipeline:
    seed = cfg["project"]["random_state"]
    sensitive = cfg["data"]["sensitive_attribute"]
    drop_sensitive = cfg["modeling"].get("drop_sensitive_from_model", True)
    steps = [("features", AdultFeatureEngineer())]
    if drop_sensitive:
        from sklearn.preprocessing import FunctionTransformer
        from functools import partial
        steps.append(("drop_sensitive", FunctionTransformer(partial(drop_sensitive_column, column=sensitive), validate=False)))
    steps += [("preprocess", make_preprocessor()), ("model", make_estimator(name, seed, params))]
    return Pipeline(steps)
