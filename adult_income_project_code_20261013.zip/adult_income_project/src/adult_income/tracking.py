from __future__ import annotations
from contextlib import contextmanager
from datetime import datetime, timezone
from pathlib import Path
import json, shutil, uuid

class FileTracker:
    """Dependency-light experiment tracker: one JSON record plus artifact folder per run."""
    def __init__(self, directory: str | Path):
        self.root = Path(directory)
        self.root.mkdir(parents=True, exist_ok=True)
        self.ledger = self.root / "runs.jsonl"

    @contextmanager
    def run(self, name: str, kind: str, params: dict | None = None):
        run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ") + "-" + uuid.uuid4().hex[:8]
        run_dir = self.root / run_id
        run_dir.mkdir(parents=True)
        record = {"run_id": run_id, "name": name, "kind": kind, "started_at": datetime.now(timezone.utc).isoformat(), "params": params or {}, "metrics": {}, "artifacts": [], "status": "running"}
        class Active:
            def log_metrics(self, metrics): record["metrics"].update({k: float(v) if isinstance(v, (int,float)) else v for k,v in metrics.items()})
            def log_params(self, params): record["params"].update(params)
            def log_artifact(self, path):
                path = Path(path); dest = run_dir / path.name
                if path.resolve() != dest.resolve(): shutil.copy2(path, dest)
                record["artifacts"].append(str(dest.relative_to(self_outer.root)))
            @property
            def directory(self): return run_dir
        self_outer = self
        active = Active()
        try:
            yield active
            record["status"] = "completed"
        except Exception as exc:
            record["status"] = "failed"; record["error"] = f"{type(exc).__name__}: {exc}"
            raise
        finally:
            record["ended_at"] = datetime.now(timezone.utc).isoformat()
            with self.ledger.open("a", encoding="utf-8") as handle: handle.write(json.dumps(record, sort_keys=True) + "\n")
