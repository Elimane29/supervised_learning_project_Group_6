from __future__ import annotations
import argparse,json,platform
from pathlib import Path
import joblib,numpy as np,pandas as pd
from sklearn.calibration import CalibratedClassifierCV
from .config import load_config,resolve
from .data import load_adult,split_data
from .fairness import group_metrics,fit_equal_opportunity_thresholds,apply_group_thresholds
from .metrics import classification_metrics,select_threshold
from .modeling import make_pipeline
from .plots import plot_eda,plot_curves,plot_confusion,plot_calibration,plot_model_comparison,plot_fairness
from .tracking import FileTracker
from .tuning import tune_model
from .explain import explain_model

def run(config_path='config.yaml',data_mode='auto',trials=None,skip_tuning=False):
    cfg=load_config(config_path);out=resolve(cfg,cfg['outputs']['artifacts_dir']);out.mkdir(parents=True,exist_ok=True)
    tracker=FileTracker(resolve(cfg,cfg['tracking']['directory']))
    X,y,source=load_adult(cfg,data_mode);splits=split_data(X,y,cfg)
    metadata={'dataset':'Adult / Census Income','source':source,'rows':int(len(X)),'features':int(X.shape[1]),'positive_rate':float(y.mean()),'random_state':cfg['project']['random_state'],'python':platform.python_version()}
    (out/'dataset_metadata.json').write_text(json.dumps(metadata,indent=2),encoding='utf-8')
    pd.DataFrame({'column':X.columns,'dtype':X.dtypes.astype(str).values,'missing':X.isna().sum().values,'unique':X.nunique(dropna=True).values}).to_csv(out/'data_audit.csv',index=False)
    plot_eda(X,y,out)
    model_rows=[];trained={};best_params_all={}
    for name in cfg['modeling']['models']:
        params={};cv_pr_auc=np.nan
        if not skip_tuning:
            params,cv_pr_auc=tune_model(name,splits.X_train,splits.y_train,cfg,out,trials)
        pipe=make_pipeline(name,cfg,params);pipe.fit(splits.X_train,splits.y_train)
        val_prob=pipe.predict_proba(splits.X_validation)[:,1];threshold,val_metrics=select_threshold(splits.y_validation,val_prob,cfg['modeling']['threshold_objective'])
        row={'model':name,'cv_pr_auc':cv_pr_auc,**val_metrics};model_rows.append(row);trained[name]=(pipe,threshold,val_prob);best_params_all[name]=params
        with tracker.run(name,'model',params) as active: active.log_metrics(row)
    comparison=pd.DataFrame(model_rows).sort_values('pr_auc',ascending=False);comparison.to_csv(out/'model_comparison.csv',index=False);plot_model_comparison(comparison,out)
    final_name=str(comparison.iloc[0].model);base,threshold,val_prob=trained[final_name]
    calibrated=CalibratedClassifierCV(base,method=cfg['modeling']['calibration_method'],cv='prefit');calibrated.fit(splits.X_validation,splits.y_validation)
    val_cal_prob=calibrated.predict_proba(splits.X_validation)[:,1];threshold,val_threshold_metrics=select_threshold(splits.y_validation,val_cal_prob,cfg['modeling']['threshold_objective'])
    test_prob=calibrated.predict_proba(splits.X_test)[:,1];test_metrics=classification_metrics(splits.y_test,test_prob,threshold)
    plot_curves(splits.y_test,test_prob,out,'final');plot_confusion(splits.y_test,(test_prob>=threshold).astype(int),out,'final');plot_calibration(splits.y_test,test_prob,out,'final')
    before_table,before_summary=group_metrics(splits.y_test,test_prob,splits.sensitive_test,threshold)
    thresholds=fit_equal_opportunity_thresholds(splits.y_validation,val_cal_prob,splits.sensitive_validation)
    mitigated_pred=apply_group_thresholds(test_prob,splits.sensitive_test,thresholds,threshold)
    after_rows=[]
    for group in sorted(pd.Series(splits.sensitive_test).fillna('Missing').astype(str).unique()):
        mask=pd.Series(splits.sensitive_test).fillna('Missing').astype(str).to_numpy()==group
        yy=np.asarray(splits.y_test)[mask];pp=np.asarray(mitigated_pred)[mask]
        from sklearn.metrics import confusion_matrix,precision_score
        tn,fp,fn,tp=confusion_matrix(yy,pp,labels=[0,1]).ravel();after_rows.append({'group':group,'selection_rate':float(pp.mean()),'tpr':float(tp/(tp+fn)) if tp+fn else np.nan,'fpr':float(fp/(fp+tn)) if fp+tn else np.nan,'ppv':float(precision_score(yy,pp,zero_division=0)),'n':int(mask.sum()),'positives':int(yy.sum())})
    after_table=pd.DataFrame(after_rows)
    def gap(t,col): return float(t[col].max()-t[col].min())
    after_summary={'demographic_parity_difference':gap(after_table,'selection_rate'),'demographic_parity_ratio':float(after_table.selection_rate.min()/after_table.selection_rate.max()) if after_table.selection_rate.max() else np.nan,'equal_opportunity_difference':gap(after_table,'tpr'),'fpr_difference':gap(after_table,'fpr'),'equalized_odds_difference':max(gap(after_table,'tpr'),gap(after_table,'fpr')),'predictive_parity_difference':gap(after_table,'ppv')}
    before_table.to_csv(out/'fairness_before.csv',index=False);after_table.to_csv(out/'fairness_after.csv',index=False);plot_fairness(before_table,after_table,out)
    explain_model(base,splits.X_test,splits.y_test,out)
    results={'dataset':metadata,'final_model':final_name,'best_params':best_params_all,'validation_threshold':threshold,'test_metrics':test_metrics,'fairness_definition':'equal opportunity (equal true-positive rates)','fairness_before':before_summary,'fairness_after':after_summary,'group_thresholds':thresholds,'mitigation_note':'Post-processing group thresholds fitted on validation data and evaluated once on untouched test data. Review legal and operational acceptability before deployment.'}
    (out/'results.json').write_text(json.dumps(results,indent=2,default=float),encoding='utf-8')
    bundle={'model':calibrated,'base_pipeline':base,'model_name':final_name,'threshold':threshold,'fairness_thresholds':thresholds,'metadata':metadata}
    model_path=resolve(cfg,cfg['outputs']['model_path']);model_path.parent.mkdir(parents=True,exist_ok=True);joblib.dump(bundle,model_path)
    return results

def main():
    p=argparse.ArgumentParser();p.add_argument('--config',default='config.yaml');p.add_argument('--data-mode',choices=['auto','openml','local','fixture'],default='auto');p.add_argument('--trials',type=int);p.add_argument('--skip-tuning',action='store_true');args=p.parse_args();results=run(args.config,args.data_mode,args.trials,args.skip_tuning);print(json.dumps(results,indent=2,default=float))
if __name__=='__main__': main()
