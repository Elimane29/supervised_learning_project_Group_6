from pathlib import Path
from adult_income.config import load_config
from adult_income.data import load_adult,split_data
from adult_income.modeling import make_pipeline

def test_end_to_end_fixture():
    root=Path(__file__).parents[1]
    cfg=load_config(root/'config.yaml')
    X,y,source=load_adult(cfg,'fixture')
    splits=split_data(X,y,cfg)
    model=make_pipeline('logistic_regression',cfg,{'C':1.0,'penalty':'l2'})
    model.fit(splits.X_train,splits.y_train)
    p=model.predict_proba(splits.X_validation)[:,1]
    assert len(p)==len(splits.y_validation)
    assert ((p>=0)&(p<=1)).all()
