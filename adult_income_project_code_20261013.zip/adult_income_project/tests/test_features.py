import pandas as pd
from adult_income.features import AdultFeatureEngineer

def test_feature_engineering_is_deterministic_and_target_free():
    X=pd.DataFrame({'age':[40],'hours-per-week':[40],'education-num':[13],'capital-gain':[1000],'capital-loss':[100],'marital-status':['Married-civ-spouse']})
    out=AdultFeatureEngineer().fit_transform(X)
    assert out.loc[0,'capital-net']==900
    assert out.loc[0,'has-capital-activity']==1
    assert out.loc[0,'education-hours']==520
    assert out.loc[0,'is-married']==1
