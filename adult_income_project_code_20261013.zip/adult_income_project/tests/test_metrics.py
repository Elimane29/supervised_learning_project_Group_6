from adult_income.metrics import classification_metrics,expected_calibration_error

def test_metrics_complete():
    m=classification_metrics([0,0,1,1],[.1,.4,.6,.9],.5)
    assert m['tp']==2 and m['tn']==2
    assert m['pr_auc']>=0 and m['brier']>=0
    assert expected_calibration_error([0,1],[.1,.9])>=0
