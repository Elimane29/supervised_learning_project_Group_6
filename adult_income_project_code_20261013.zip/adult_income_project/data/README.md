# Data

The final project loader uses `fetch_openml(name="adult", version=2, as_frame=True)`, exactly as specified in the official brief.

`adult_sample.csv` is a small real-data fixture retained only for offline unit and smoke tests. It is not suitable for final model reporting. If network access is unavailable, place a full cached copy at `data/adult.csv`; the loader will use it and record the source in `artifacts/dataset_metadata.json`.

Do not commit confidential or manually altered data. Missing values represented by `?` are converted to nulls inside the pipeline.
